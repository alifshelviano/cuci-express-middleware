// middleware.js

// Logger middleware
function logger(req, res, next) {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
}

// Validation middleware for POST /items
function validateItem(req, res, next) {
  const { name, type } = req.body;
  if (!name || !type) {
    return res.status(400).json({ error: 'Both name and type are required' });
  }
  next();
}

module.exports = { logger, validateItem };
