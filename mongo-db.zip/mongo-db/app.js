require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const { logger, validateItem } = require('./middleware');
const Item = require('./models/item');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(logger);

// --- Connect to MongoDB ---
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// --- Routes ---
app.get('/items', async (req, res) => {
  const items = await Item.find();
  res.json(items);
});

app.post('/items', validateItem, async (req, res) => {
  try {
    const newItem = new Item(req.body);
    await newItem.save();
    res.status(201).json(newItem);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.listen(port, () => {
  console.log(`🚀 Server running on http://localhost:${port}`);
});
