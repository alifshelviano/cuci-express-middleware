// models/Item.js
const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, required: true },
  status: { type: String, default: 'pending' }
});

const Item = mongoose.model('Item', itemSchema);
module.exports = Item;
